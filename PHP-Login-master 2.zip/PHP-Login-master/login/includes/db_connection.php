<?php

/* Adapted from https://github.com/fethica/PHP-Login */
/*Team Ruby*/
/*
Victoria Cummings
Michelle Kim
Yin Song
Xiao Jiang
*/
// Extend this class to re-use db connection
function OpenCon()//modified by zoe
{
    //echo"yo";
    //public $conn; modified by zoe
    //public function __construct()
    //{
    // require '../dbconf.php';
    $dbhost = 'localhost'; //Host name modified by zoe
    $dbuser= 'root'; // Mysql username modified by zoe
    $dbpass = 'centre79,'; // Mysql password modified by zoe
    $db = 'HackerTracker'; // Database name modified by zoe
    // $this->tbl_prefix = ''; // Prefix for all database tables
    //$this->tbl_members = 'Students';////////////needs to be modified by Zoe
    //$this->tbl_attempts = 5;

    try {
        // Connect to server and select database.
        $conn = new mysqli($dbhost,$dbuser,$dbpass,$db);//modified by zoe
        //$this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        if ($conn->connect_error)
        {
            die("Connection failed: " . $conn->connect_error);
        }
        return $conn;
    }
    catch (\Exception $e) {
        die('Database connection error');
    }
    //}
}
?>