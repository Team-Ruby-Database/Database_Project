<?php
/* Adapted from https://github.com/fethica/PHP-Login */
/*Team Ruby*/
/*
Victoria Cummings
Michelle Kim
Yin Song
Xiao Jiang
*/
//PUT THIS HEADER ON TOP OF EACH UNIQUE PAGE
session_start();
if (!isset($_SESSION['username']))
{
    return header("location:login/main_login.php");
}
