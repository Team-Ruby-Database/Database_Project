<?php
/* Adapted from https://github.com/fethica/PHP-Login */
/*Team Ruby*/
/*
Victoria Cummings
Michelle Kim
Yin Song
Xiao Jiang
*/
include 'db_connection.php';
$conn = OpenCon();
/*class LoginForm //extends db_connection.php //modified by zoe
{

    public function __constructor()
    {
        $this->objs = new LoginForm();
    }*/
    function checkLogin($useremail, $password,$identity,$conn)
    {

        //$conf = new GlobalConf;
        //$ip_address = $conf->ip_address;
       // $login_timeout = $conf->login_timeout;
       // $max_attempts = $conf->max_attempts;
        //$timeout_minutes = $conf->timeout_minutes;
        //$attcheck = checkAttempts($useremail);
       // $curr_attempts = $attcheck['attempts'];

       // $datetimeNow = date("Y-m-d H:i:s");
       // $oldTime = strtotime($attcheck['lastlogin']);
       //$newTime = strtotime($datetimeNow);
       // $timeDiff = $newTime - $oldTime;
       // $tbl_members = $db->tbl_members;
        //echo "what?";
        try {
////////////////needs to be modified...modified by zoe
            //$db = new DbConn;
            if ($identity=='Professor') {
                $tbl_members = "Professors";
            }

            else if($identity=='Student'){
                $tbl_members = "Students";
            }
            //$tbl_members = $db->tbl_members;
            $err = '';

        } catch (PDOException $e) {

            $err = "Error: " . $e->getMessage();

        }

        $result = $conn->query("SELECT * FROM '$tbl_members' WHERE '$tbl_members'.'_Email' = '$useremail' AND '$tbl_members'.'_Password' = '$password'");//
       // $stmt->bindParam(':useremail', $useremail);//Modified by zoe
        //$stmt->execute();

        // Gets query result
        //$result = $stmt->fetch(PDO::FETCH_ASSOC);

        //if ($curr_attempts >= $max_attempts && $timeDiff < $login_timeout) {

            //Too many failed attempts
            //$success = "<div class=\"alert alert-danger alert-dismissable\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>Maximum number of login attempts exceeded... please wait ".$timeout_minutes." minutes before logging in again</div>";

        //} else {

             //If max attempts not exceeded, continue
            // Checks password entered against db password hash
            //if (password_verify($password, $result['password']) && $result['verified'] == '1') { //modified by zoe
            if ($result-> num_rows > 0) {


            //Success! Register $myusername, $mypassword and return "true"
                $success = 'true';
                    session_start();
                    $userid = $conn->query("SELECT '$tbl_members'.'_ID' FROM '$tbl_members' WHERE '$tbl_members'.'_Email' = '$useremail'");

                $_SESSION['username'] = $userid;//needs to be changed to ID

            } //elseif (password_verify($password, $result['password']) && $result['verified'] == '0') {

                //Account not yet verified
                //$success = "<div class=\"alert alert-danger alert-dismissable\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>Your account has been created, but you cannot log in until it has been verified</div>"; //modified by zoe

           // }
            else {

                //Wrong username or password
                $success = "<div class=\"alert alert-danger alert-dismissable\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>Wrong Username or Password</div>";

            }
        return $success;

        //return $success;
   // }

    //public function insertAttempt($username)
   // {
 /*       try {
            $db = new DbConn;
            $conf = new GlobalConf;
            $tbl_attempts = $db->tbl_attempts;
            $ip_address = $conf->ip_address;
            $login_timeout = $conf->login_timeout;
            $max_attempts = $conf->max_attempts;

            $datetimeNow = date("Y-m-d H:i:s");
            $attcheck = checkAttempts($username);
            $curr_attempts = $attcheck['attempts'];

            $stmt = $db->conn->prepare("INSERT INTO ".$tbl_attempts." (ip, attempts, lastlogin, username) values(:ip, 1, :lastlogin, :username)");
            $stmt->bindParam(':ip', $ip_address);
            $stmt->bindParam(':lastlogin', $datetimeNow);
            $stmt->bindParam(':username', $username);
            $stmt->execute();
            $curr_attempts++;
            $err = '';

        } catch (PDOException $e) {

            $err = "Error: " . $e->getMessage();

        }

        //Determines returned value ('true' or error code)
        $resp = ($err == '') ? 'true' : $err;

        return $resp;

    }

    public function updateAttempts($username)
    {
        try {
            $db = new DbConn;
            $conf = new GlobalConf;
            $tbl_attempts = $db->tbl_attempts;
            $ip_address = $conf->ip_address;
            $login_timeout = $conf->login_timeout;
            $max_attempts = $conf->max_attempts;
            $timeout_minutes = $conf->timeout_minutes;

            $att = new LoginForm;
            $attcheck = checkAttempts($username);
            $curr_attempts = $attcheck['attempts'];

            $datetimeNow = date("Y-m-d H:i:s");
            $oldTime = strtotime($attcheck['lastlogin']);
            $newTime = strtotime($datetimeNow);
            $timeDiff = $newTime - $oldTime;

            $err = '';
            $sql = '';

            if ($curr_attempts >= $max_attempts && $timeDiff < $login_timeout) {

                if ($timeDiff >= $login_timeout) {

                    $sql = "UPDATE ".$tbl_attempts." SET attempts = :attempts, lastlogin = :lastlogin where ip = :ip and username = :username";
                    $curr_attempts = 1;

                }

            } else {

                if ($timeDiff < $login_timeout) {

                    $sql = "UPDATE ".$tbl_attempts." SET attempts = :attempts, lastlogin = :lastlogin where ip = :ip and username = :username";
                    $curr_attempts++;

                } elseif ($timeDiff >= $login_timeout) {

                    $sql = "UPDATE ".$tbl_attempts." SET attempts = :attempts, lastlogin = :lastlogin where ip = :ip and username = :username";
                    $curr_attempts = 1;

                }

                $stmt2 = $db->conn->prepare($sql);
                $stmt2->bindParam(':attempts', $curr_attempts);
                $stmt2->bindParam(':ip', $ip_address);
                $stmt2->bindParam(':lastlogin', $datetimeNow);
                $stmt2->bindParam(':username', $username);
                $stmt2->execute();

            }

        } catch (PDOException $e) {

            $err = "Error: " . $e->getMessage();

        }

        //Determines returned value ('true' or error code) (ternary)
        $resp = ($err == '') ? 'true' : $err;

        return $resp;

    }*/

}
