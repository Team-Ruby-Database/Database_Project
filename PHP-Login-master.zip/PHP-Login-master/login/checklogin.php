<?php
/* Adapted from https://github.com/fethica/PHP-Login */
/*Team Ruby*/
/*
Victoria Cummings
Michelle Kim
Yin Song
Xiao Jiang
*/
//DO NOT ECHO ANYTHING ON THIS PAGE OTHER THAN RESPONSE
//'true' triggers login success

ob_start();

include 'config.php';
//include 'db_connection.php';
$conn = OpenCon();
//include 'LoginForm.php';
require 'includes/functions.php';
// Define $myusername and $mypassword

$useremail = $_POST['myuseremail'];//indicates Email, modified by zoe
$password = $_POST['mypassword'];//modified by zoe
$identity = $_POST['class'];//Zoe added/modified

// To protect MySQL injection
//$useremail = stripslashes($useremail);
//$password = stripslashes($password);
//$identity  = stripslashes($identity);//Zoe added/modified

//$response = '';
//echo "bas";
//$loginCtl = new LoginForm;
//echo "bas";

        if($identity=="Students"){
            $condition = "Student";
        }
        elseif ($identity=="Professors"){
            $condition = "Professor";
        }

        $condition1 = $condition."_Email";
        $condition2 = $condition."_Password";
        $condition3 = $condition."_ID";


$result = $conn->query("SELECT * FROM ".$identity." WHERE $condition1 = '$useremail' AND $condition2 = '$password'");
    //select any record that match the email and password

if ($result-> num_rows > 0) {//if there is no result


    //Success! Register $myusername, $mypassword and return "true"
    $success = 'true';
    session_start();
    //$sql2 = "SELECT * FROM ".$identity." WHERE $condition = $newid";

    $userid = $conn->query("SELECT $condition3 FROM ".$identity." WHERE $condition1 = '$useremail'");
    //get ID

    $_SESSION['username'] = $userid;//needs to be changed to ID

    if (isset($_SESSION['username'])&& $identity=='Professors') {
        header("Location:professorClasses.php");//redirect according to the identity
        exit;
    }
    else if(isset($_SESSION['username'])&& $identity=='Students'){

        header("Location:studentClasses.php");
        exit;
    }

}

else {

    //Wrong username or password
    echo "Error: Wrong Username or Password";



}



/*
if ($success != 'true') {//modified by zoe

    //$loginCtl->updateAttempts($useremail);
    $resp = new RespObj($useremail, $success);
    $jsonResp = json_encode($resp);
    echo $jsonResp;

} else { //modified by zoe

   $resp = new RespObj($useremail, $success);
   $jsonResp = json_encode($resp);
   echo $jsonResp;

}*/



//unset($resp, $jsonResp);
ob_end_flush();
?>
