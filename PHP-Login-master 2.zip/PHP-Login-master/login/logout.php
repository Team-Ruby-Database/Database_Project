<?php
/* Adapted from https://github.com/fethica/PHP-Login */
/*Team Ruby*/
/*
Victoria Cummings
Michelle Kim
Yin Song
Xiao Jiang
*/
    session_start();
    session_destroy();
    header("location:main_login.php");
