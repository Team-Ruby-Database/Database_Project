<?php
/* Adapted from https://github.com/fethica/PHP-Login */
/*Team Ruby*/
/*
Victoria Cummings
Michelle Kim
Yin Song
Xiao Jiang
*/
  session_start();

  if (isset($_SESSION['username'])) {
      session_start();
      session_destroy();
  }


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Signup</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="../css/bootstrap.css" rel="stylesheet" media="screen">
    <link href="../css/main.css" rel="stylesheet" media="screen">
  </head>

  <body>
    <div class="container">

      <!--<form class="form-signup" id="usersignup" name="usersignup" method="POST" action="createuser.php">-->
          <form action="createuser.php" method="POST"><!--Zoe modified-->
        <h2 class="form-signup-heading">Welcome to the HackerTracker</h2>
          <input name="LastName" id="LastName" type="text" class="form-control" placeholder="Your Last Name">
          <input name="FirstName" id="FirstName" type="text" class="form-control" placeholder="Your First Name">
        <input name="newuser" id="newuser" type="text" class="form-control" placeholder="Your Student/Professor ID" autofocus>
        <input name="email" id="email" type="text" class="form-control" placeholder="Email">

<br>
        <input name="password1" id="password1" type="password" class="form-control" placeholder="Password">
        <input name="password2" id="password2" type="password" class="form-control" placeholder="Repeat Password">

          <!--Let the user choose his/her class so that we can use his/her username and password
          to determine in which specific table we should search-->
          <input type="radio" name="class" value="Professor"> I am a professor <br>
          <input type="radio" name="class" value="Student"checked> I am a student<br><!--Zoe modified-->

        <!--<button name="Submit" id="submit"  type="submit">Sign up</button>-->
              <input type="submit" name="submitter" value="Sign Up"/><!--Zoe modified-->

        <div id="message"></div>
      </form>

    </div> <!-- /container -->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="//code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script type="text/javascript" src="js/bootstrap.js"></script>

    <script src="js/signup.js"></script>


    <script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<script>

$( "#usersignup" ).validate({
  rules: {
	email: {
		email: true,
		required: true
	},
    password1: {
      required: true,
      minlength: 4
	},
    password2: {
      equalTo: "#password1"
    }
  }
});
</script>

  </body>
</html>
