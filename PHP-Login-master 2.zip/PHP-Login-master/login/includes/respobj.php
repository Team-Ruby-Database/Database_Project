<?php
/* Adapted from https://github.com/fethica/PHP-Login */
/*Team Ruby*/
/*
Victoria Cummings
Michelle Kim
Yin Song
Xiao Jiang
*/
class RespObj
{
    public $username;
    public $response;
    public function __construct($username, $response)
    {

        $this->username = $username;
        $this->response = $response;

    }
}
