<?php
/* Adapted from https://github.com/fethica/PHP-Login */
/*Team Ruby*/
/*
Victoria Cummings
Michelle Kim
Yin Song
Xiao Jiang
*/
//session_start();
include 'db_connection.php';
$conn = OpenCon();
/*class newuserform //extends DbConn
{
    public function __constructor()
    {
        $this->objs = new newuserform();
    }*/
    function createUser($newid, $lastname, $firstname, $newemail, $newpw,$identity,$conn)
        //($usr, $uid, $email, $pw)
    {

        $success='false';

        try {
            //echo "bas";



            //$tbl_members = $db->tbl_members;//////////need to be modified
            // prepare sql and bind parameters
            //$stmt = $db->conn->prepare("INSERT INTO ".$tbl_members."(:id, :LastName, :FirstName, :Email, :Password)
            $sql = "INSERT INTO '$identity' VALUES ('$newid','$lastname','$firstname','$newemail','$newpw')";
            $result1 = $conn->query($sql);//modified by zoe

            $sql2 = "SELECT * FROM  '$identity' WHERE '$identity'.'_ID'= '$newid'";
            $result2 = $conn->query($sql2);
            if($result2->num_rows>0){
                //echo "Congratulations! You have signed up successfully. Please back to login...";
                //header('Location:../main_login.php');
                $success = 'true';

            }
            return $success;

            //$stmt->bindParam(':id', $uid);
         /*   $stmt->bindParam(':ID', $newid);
            $stmt->bindParam(':LastName', $lastname);
            $stmt->bindParam(':FirstName', $firstname);
            $stmt->bindParam(':Email', $newemail);
            $stmt->bindParam(':Password', $newpw);
            $stmt->execute();*/

            $err = '';

        } catch (PDOException $e) {

            $err = "Error: " . $e->getMessage();

        }
        //Determines returned value ('true' or error code)
       /* if ($err == '') {

            $success = 'true';

        } else {

            $success = $err;

        };*/

        //return $success;

    }
