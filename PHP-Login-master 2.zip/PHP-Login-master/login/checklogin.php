<?php
/* Adapted from https://github.com/fethica/PHP-Login */
/*Team Ruby*/
/*
Victoria Cummings
Michelle Kim
Yin Song
Xiao Jiang
*/
//DO NOT ECHO ANYTHING ON THIS PAGE OTHER THAN RESPONSE
//'true' triggers login success

ob_start();

include 'config.php';
include 'db_connection.php';
$conn = OpenCon();
//include 'LoginForm.php';
//require 'includes/functions.php';
// Define $myusername and $mypassword

$useremail = $_POST['myuseremail'];//indicates Email, modified by zoe
$password = $_POST['mypassword'];//modified by zoe
$identity = $_POST['class'];//Zoe added/modified

// To protect MySQL injection
$useremail = stripslashes($useremail);
$password = stripslashes($password);
$identity  = stripslashes($identity);//Zoe added/modified

//$response = '';
//echo "bas";
//$loginCtl = new LoginForm;
//echo "bas";

//$conf = new GlobalConf;
//$lastAttempt = checkAttempts($useremail);
//$max_attempts = $conf->max_attempts;


//First Attempt   modified and commented by zoe
//if ($lastAttempt['lastlogin'] == '') {

   // $lastlogin = 'never';
    //$loginCtl->insertAttempt($useremail);
   // $response = $loginCtl->checkLogin($useremail, $password);

//} elseif ($lastAttempt['attempts'] >= $max_attempts) {

    //Exceeded max attempts
   // $loginCtl->updateAttempts($useremail);
   // $response = $loginCtl->checkLogin($useremail, $password);

//} else {

    $response = checkLogin($useremail, $password,$identity,$conn);

//};

if ($response != 'true') {//modified by zoe

    //$loginCtl->updateAttempts($useremail);
    $resp = new RespObj($useremail, $response);
    $jsonResp = json_encode($resp);
    echo $jsonResp;

} else { //modified by zoe

   $resp = new RespObj($useremail, $response);
   $jsonResp = json_encode($resp);
   echo $jsonResp;

}

//unset($resp, $jsonResp);
ob_end_flush();
?>
