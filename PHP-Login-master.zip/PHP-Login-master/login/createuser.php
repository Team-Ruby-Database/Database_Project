<?php
/* Adapted from https://github.com/fethica/PHP-Login */
/*Team Ruby*/
/*
Victoria Cummings
Michelle Kim
Yin Song
Xiao Jiang
*/

//require 'includes/functions.php';
include_once 'config.php';
//include 'db_connection.php';
$conn = OpenCon();

//Pull username, generate new ID and hash password
$newid = $_POST['newuser'];//uniqid(rand(), false);//Zoe modified
$newemail = $_POST['email'];//student/professor email(login account)
$lastname = $_POST['LastName'];
$firstname = $_POST['FirstName'];

//$newpw = password_hash($_POST['password1'], PASSWORD_DEFAULT);
$pw1 = $_POST['password1'];//modified
$pw2 = $_POST['password2'];

$identity = $_POST['class'];//Zoe added/modified

    //Enables moderator verification (overrides user self-verification emails)
//if (isset($admin_email)) {

    //$newemail = $admin_email;

//} else {

    //$newemail = $_POST['email']; modified by zoe

//}

//Validation rules
if ($pw1 != $pw2)
{
    echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Password fields must match</div><div id="returnVal" style="display:none;">false</div>';

}
elseif (strlen($pw1) < 4)
{

    echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Password must be at least 4 characters</div><div id="returnVal" style="display:none;">false</div>';

} //elseif (!filter_var($newuser, FILTER_VALIDATE_EMAIL) == true)
//{

    //echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Must provide a valid email address</div><div id="returnVal" style="display:none;">false</div>';

//}//modified by zoe
else
{
    //Validation passed
    if (isset($_POST['newuser']) && !empty(str_replace(' ', '', $_POST['newuser'])) && isset($_POST['password1']) && !empty(str_replace(' ', '', $_POST['password1'])))
    {

        //Tries inserting into database and add response to variable

        //$a = new newuserform;

        //$response = createUser($newid,$lastname,$firstname,$newemail,$newpw,$identity,$conn);//modified by zoe
        //echo"bas";




            //insert all information the user filled into responding table
            $sql = "INSERT INTO ".$identity." VALUES ('$newid', '$lastname', '$firstname', '$newemail', '$pw1')";
            //echo"$pw1";
            $result1 = $conn->query($sql);//modified by zoe

            if($identity=="Students"){
                $condition = "Student";
            }
            elseif ($identity=="Professors"){
                $condition = "Professor";
            }
            $condition = $condition."_ID";
            $sql2 = "SELECT * FROM ".$identity." WHERE $condition = $newid";

            $result2 = $conn->query($sql2);//check whether successfully insert the tuple

            if($result2->num_rows>0){//if it has been inserted successfully

                $success = 'true';

            }else {

                $success='false';
            }

        //Success
        if ($success == 'true')
        {
            //echo congratulation information and redirect to the login page
            echo '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'. $activemsg .'</div><div id="returnVal" style="display:none;">true</div>';

            //Send verification email
            //$m = new MailSender;
            //$m->sendMail($newemail, $newuser, $newid, 'Verify');

        }
        else
        {
            //Failure
            echo "Oops, something went wrong..";

        }



    }




    else
    {

        //Validation error from empty form variables
        echo 'An error occurred on the form... try again';
    }
};
